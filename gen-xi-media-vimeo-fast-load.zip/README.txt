GEN XI MEDIA WEBSITE - GOOGLE SHEET + CALENDLY SETUP

WHAT IS ALREADY DONE
- The form fields are mandatory.
- The submit button saves form data first.
- After saving, it redirects the visitor to Calendly:
  https://calendly.com/nadeem31arqumm/30min
- The Vimeo videos are embedded in the 4 vertical cards.

WHAT YOU STILL NEED TO DO ONCE
1. Open https://script.google.com
2. Create a new project.
3. Open the included google-apps-script.js file.
4. Copy all code from google-apps-script.js and paste it into Apps Script.
5. Click Deploy > New deployment.
6. Select type: Web app.
7. Execute as: Me.
8. Who has access: Anyone.
9. Click Deploy and copy the Web App URL.
10. Open index.html.
11. Find this line:
    const GOOGLE_SCRIPT_URL = 'PASTE_YOUR_DEPLOYED_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE';
12. Replace only the text inside quotes with your Web App URL.
13. Save index.html and upload the website files to Hostinger/GoDaddy.

IMPORTANT
The public Google Sheet link itself cannot directly receive website form submissions.
Google requires an Apps Script Web App URL as the backend bridge.

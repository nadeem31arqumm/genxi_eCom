// Google Apps Script backend for the Gen Xi Media website form.
// 1. Open https://script.google.com
// 2. Create a new project
// 3. Paste this code
// 4. Deploy > New deployment > Web app
// 5. Execute as: Me
// 6. Who has access: Anyone
// 7. Copy the Web App URL and paste it into GOOGLE_SCRIPT_URL inside index.html

const SPREADSHEET_ID = '1ZGXRQRfSOLMBb3bK6UasuRXh1nNacuxT59Jy__2nMjo';
const SHEET_NAME = 'Leads';

function doPost(e) {
  const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME) || SpreadsheetApp.openById(SPREADSHEET_ID).insertSheet(SHEET_NAME);
  const data = JSON.parse(e.postData.contents || '{}');

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Submitted At', 'Name', 'Email', 'Phone', 'Agency / Website', 'Active eCom Clients', 'Ad Videos Tested', 'Creative Budget', 'Meeting']);
  }

  sheet.appendRow([
    data.submittedAt || new Date(),
    data.name || '',
    data.email || '',
    data.phone || '',
    data.agency || '',
    data.clients || '',
    data.videosTested || '',
    data.budget || '',
    data.meeting || ''
  ]);

  return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
}
